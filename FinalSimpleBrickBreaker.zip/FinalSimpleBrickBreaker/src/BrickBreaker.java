// Tyler Dean                               Brick Breaker Game (for Project 2)                          15 October 2024

/***
 * This class is the main class of this BrickBreaker game. It contains main and
 * is the driver class.
 */
public class BrickBreaker {

    /**
     * This is the main method of my BrickBreaker game. It uses the other classes in
     * this project to simply create and run the game
     * 
     * @SuppressWarnings("unused") // to remove the unused warning on
     * BrickBreakerLauncher object in main method
     * 
     * @param args // the default param for main
     */
    @SuppressWarnings("unused") // to remove the unused warning on BrickBreakerLauncher object in main method
    public static void main(String[] args) {
        TheGUI BrickBreakerLauncher = new TheGUI("BrickBreaker"); // I am able to create THEGUI object with all elements
                                                                  // needed inside, thanks to my "THEGUI" custom class

    }
}