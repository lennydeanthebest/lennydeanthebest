// Tyler Dean                               Brick Breaker Game (for Project 2)                          15 October 2024

///* I recieved help from the help room by Kalen on 10/16, Blake on 10/18, and Reece on 10/23 and 10/24 with this project */

///* This code was retrieved from my CS1181 instructor Dr. Raymer's GitHub Repository (He gave me permission) */
///* I may make modifications based on my needs for this game */
///*------------------------------------------------------------------------------------------------------------------------------

// Imports
import javax.swing.*;
import java.awt.*;

/**
 * Class BouncePanel - A panel with a bouncing circle inside
 * 
 * @author Michael Raymer
 */
public class BouncePanel extends JPanel {
    private int circleSize; // Radius of the bouncing circle
    private int circleX; // X coordinate of the circle (see java.awt.Graphics.drawOval)
    private int circleY; // Y coordinate of the circle (see java.awt.Graphics.drawOval)
    private int deltaX; // Current x direction/speed
    private int deltaY; // Current y direction/speed
    // Most of this should be passed as parameters and specified when
    // the pane is created!
    /**
     * This is the constructor for a BouncePanel. This constrcutor was given to me
     * by code from Dr. Raymer's GitHub repository
     * 
     * @param d // dimension passed into constructor
     */
    public BouncePanel(Dimension d) {
        super(); // inherit all methods of the parent class (JPanel)
        this.setSize(d); // the size of the paddle is it's dimension
        circleSize = 20; // the default size of the circle
        circleX = 20; // default circle x value
        circleY = 20; // default circle y value
        deltaX = 1; // default circle deltaX value
        deltaY = 1; // default circle deltaY value
    }

    /// * Javadoc comments are not needed for getters or setters according to CS1181
    /// rules */

    public void setCircleX(int circleX) {
        this.circleX = circleX;
    }

    public void setCircleY(int circleY) {
        this.circleY = circleY;
    }

    public void setCircleDeltaX(int deltaX) {
        this.deltaX = deltaX;
    }

    public void setCircleDeltaY(int deltaY) {
        this.deltaY = deltaY;
    }

    public int getCircleX() {
        return circleX;
    }

    public int getCircleY() {
        return circleY;
    }

    public int getDeltaX() {
        return deltaX;
    }

    public int getDeltaY() {
        return deltaY;
    }

    /**
     * This method's purpose is to override the default paintComponent method. It is
     * called when a window needs re-drawn
     * 
     * @param g // Graphics object e is a object that handles drawing
     */
    public void paintComponent(Graphics g) {

        g.setColor(Color.RED); // color currently set to red, can be changed to any color other than colors
                               // used for the paddle, rootPanel, and bricks
        g.fillOval(circleX, circleY, circleSize, circleSize);

        // Note that the x and y coordinates are the upper left corner of the
        // rectangular
        // bounding box of the circle. See the documentation for
        // java.awt.Graphics.drawOval()
        // for details.
        g.drawOval(circleX, circleY, circleSize, circleSize);

    }

    // We need a thread to update the circle. Can't do it on redraw or it will only
    // happen when the window is moved, etc.

    /**
     * This method may need more work, but currently is responcible for controling
     * the movement of the circle (ball). It is similar to the animate method from
     * Paddle.java
     */
    public void animate() {

        // Move the circle
        circleX += deltaX;
        circleY += deltaY;

        // Check to see if ball hit the paddle, if so reverse it's direction (done in
        // THEGUI.java so that ball and paddle have access to each other)

        // Check if it hit the left side. If so, reverse the x direction.
        // Since we are updating several pixels at a time, the circle could extend
        // beyond the left side (i.e. circleX could be negative). If so, set it
        // to zero.
        if (circleX <= 0) {
            circleX = 0;
            deltaX *= -1;
        }

        // Now check if the circle hit the top and fix as above
        if (circleY <= 0) {
            circleY = 0;
            deltaY *= -1;
        }


        // Right side collision check.
        // Again, we might extend beyond the panel width. If so,
        // fix it by moving the circle so that it is flush against the
        // right side of the panel.
        if ((circleX + circleSize) >= getWidth()) {
            circleX = getWidth() - circleSize;
            deltaX *= -1;
        }

        // If the ball hits the bottom, player loses the game
        if ((circleY - circleSize) >= getHeight()) {
            JOptionPane losingScreen = new JOptionPane();
            JOptionPane.showMessageDialog(losingScreen, "You lost BrickBreaker! Relaunch to play again",
                    "You lost the game!", 0);
            System.exit(0); // exit the game

        }
        
    }
}
/// *-------------------------------------------------------------------------------------------------------------------------------