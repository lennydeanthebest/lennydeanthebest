// Tyler Dean                               Brick Breaker Game (for Project 2)                          15 October 2024

///* I recieved help from the help room by Kalen on 10/16, Blake on 10/18, and Reece on 10/23 and 10/24 with this project */

// Imports

import javax.swing.JComponent;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;

/***
 * This class defines what a brick is (the bricks in BrickBreaker exist to
 * be smashed by the ball) and it's methods
 */
public class Brick extends JComponent {

    // fields
    private int brickX; // declare a brick's x coordinate
    private int brickY; // declare a brick's y coordinate
    private Dimension d; // declare a brick's dimension

    /**
     * This constructor defines a Brick object
     * 
     * @param brickX // passed in brick x coordinate
     * @param brickY // passed in brick y coordinate
     * @param d      // passed in brick dimension
     */
    public Brick(int brickX, int brickY, Dimension d) {
        super(); // inherits JComponent's constructor
        this.d = (d); // assigning field dimension = param
        this.brickX = brickX; // assigning field x coordinate = param
        this.brickY = brickY; // assigning field y coordinate = param

        this.setBounds(this.brickX, this.brickY, this.d.width, this.d.height); // the bounds of a brick should be it's
                                                                               // given properties

    }

    /// * Javadoc comments are not needed for getters or setters according to CS1181
    /// rules */

    public void setBrickX(int brickX) {
        this.brickX = brickX;
    }

    public void setBrickY(int brickY) {
        this.brickY = brickY;
    }

    public int getBrickX() {
        return brickX;
    }

    public int getBrickY() {
        return brickY;
    }

    /**
     * This method overrides the default paintComponent method to paint Bricks
     * 
     * @param g // Graphics object passed into method which is used to draw
     * @Override // annotation to make intentional overriding clear
     */
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(Color.YELLOW); // color currently set to yellow, can be changed to any color other than colors
                                  // used for the paddle, ball, and rootPanel
        g.fillRect(0, 0, (int) d.getWidth(), (int) d.getHeight()); // draw and fill the g Graphics object with the set
                                                                   // color using given x, y, width and height
                                                                   // also getWidth() and getHeight() return as double
                                                                   // so they each must be typecasted to an int
        // Note that the x and y coordinates are the upper left corner of the
        // rectangular bounding box of the rectangle

    }

}
