// Tyler Dean                               Brick Breaker Game (for Project 2)                          15 October 2024

///* I recieved help from the help room by Kalen on 10/16, Blake on 10/18, and Reece on 10/23 and 10/24 with this project */

// Imports
import javax.swing.JComponent;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;

/***
 * This class defines what a paddle is (the platform needed for BrickBreaker)
 * and it's methods
 */
public class Paddle extends JComponent {

    private int paddleX; // the x value of the paddle
    private int paddleY; // the y value of the paddle
    private int deltaX = 0; // the speed and direction of the paddle

    /**
     * This is the constructor for a Paddle. It has an x value, y value, and
     * dimension
     * 
     * @param paddleX // x value passed into constructor
     * @param paddleY // x value passed into constructor
     * @param d       // dimension passed into constructor
     */
    public Paddle(int paddleX, int paddleY, Dimension d) {
        super(); // inherit all methods of the parent class (JComponent)
        this.setSize(d); // the size of the paddle is it's dimension
        this.paddleX = paddleX; // setting field value = param
        this.paddleY = paddleY; // setting field value = param
    }

    /// * Javadoc comments are not needed for getters or setters according to CS1181
    /// rules */
    public void setPaddleX(int paddleX) {
        this.paddleX = paddleX; // set field value of paddleX to = param
    }

    public int getPaddleX() {
        return paddleX; // retrieve the paddle's x value
    }

    /**
     * This method needs more work, but currently is responcible for controling the
     * movement of the paddle. It is similar to the animate method from
     * BouncePanel.java
     */
    public void animate() {
        paddleX += deltaX; // move the paddle by deltaX value + it's x value
        if (paddleX < this.getX()) { // if the paddleX value is less than it's current x value
            paddleX = this.getX(); // set it's x value = to it's current x value
        }

        if (paddleX > this.getWidth() - 100) { // if the paddleX value is greater than it's current width - 100
            paddleX = this.getWidth() - 100; // set it's width value = to it's current width value
        }

    }

    /**
     * This method simply assigns deltaX to = -5 if the moveLeft() method is called
     */
    public void moveLeft() {
        deltaX = -5; // assigns deltaX to be negative 5
    }

    /**
     * This method simply assigns deltaX to = 5 if the moveRight() method is called
     */
    public void moveRight() {
        deltaX = 5; // assigns deltaX to be positive 5
    }

    /**
     * This method simply assigns deltaX to = 0 if the moveRight() method is called,
     * stopping the paddle
     */
    public void paddleStop() {
        deltaX = 0; // assigns deltaX to be 0 which stops the paddle
    }

    /**
     * This method's purpose is to override the default paintComponent method. It is
     * called when a window needs re-drawn
     * 
     * @param g // Graphics object e is a object that handles drawing
     */
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(Color.BLUE); // color currently set to blue, can be changed to any color other than colors
                                // used for the rootPanel, ball, and bricks
        g.fillRect(paddleX, paddleY, 100, 20); // fill the g Graphics object with the set color

        // Note that the x and y coordinates are the upper left corner of the
        // rectangular bounding box of the rectangle
        g.drawRect(paddleX, paddleY, 100, 20); // actually draw the Graphics object as a rectangle with paddleX,
                                               // paddleY, width and height passed in

    }
}
