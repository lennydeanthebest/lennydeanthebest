

/**
 * Name: Actor {class}
 * @author Tyler Dean
 * @dependancies none
 * Data type class to store players of the game.  
 */

public class Actor {
    private String name;
    private int health;
    private int row;
    private int column;
    private boolean alive;
    

    /**
     * empty constructor
     */
    public Actor(){
    }

    /**
     * constructor used for initial creation of monsters
     * @param char_name     name of Actor/player/monster
     * @param health        numeric integer representing health points of data type
     */
    public Actor(String char_name, int health) {
        this.name = char_name;
        this.health = health;
    }
    
    /**
    * sets up row of catacomb
    * @param newRow    what row we are setting
    */
    public void setRow(int newRow){
        this.row = newRow;
    }

    /**
     * provides row # in catacomb of selected object
     * @return integer representing the row of selected player/monster
     */
    public int getRow(){ 
        return this.row;
    }

    /**
     * sets column # in catacomb of selected object
     * @param newColumn     what column we are setting
     */
    public void setColumn(int newColumn){ // sets up column of catacomb
        this.column = newColumn;
    }

    /**
     * provides column # in catacomb of selected object
     * @return integer representing the column of selected player/monster
     */
    public int getColumn(){ // allow column of catacomb to be called from main
        return this.column;
    }

    /**
     * sets health of selected player/monster
     * @param health integer representing the player/monster to modify
     */
    public void setHealth(int health) {
        this.health = health;
    }

    /**
     * provides health of selected player/monster
     * @return this.health      integer representing the health of the player/monster
     */
    public int getHealth(){
        return this.health;
    }

    /**
    * Checks to see if the selected player is still alive
    * @return this.alive           boolean true/false representing if the monster is still alive
    */
        public boolean isAlive(){
        return this.alive;
    }

    /**
     * Sets the selected Actor type to be alive (true/false)
     */
    public void setAlive(){
        this.alive = true;
    }

    /**
     * Sets the selected Actor type to be dead (true/false)
     */
        public void kill(){
        this.alive = false;
    }
}
