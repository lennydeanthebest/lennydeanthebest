# Project 4: Catacomb Crawler 

## Project Description

Welcome to the README.md file for my fourth java project. Here you will find a description of all information needed to play the game, as well as any other relevant information relating to the project. The purpose of this project is to create a interactable game where the player gives input to move their "hero" character around a catacomb. The catacomb is filled with monsters that will try and attack the hero while they are traversing the catacomb. The hero starts in the top left of whatever size catacomb they choose, and must make it to the bottom right of their catacomb before they run out of health.   

## Project Guide

### Dependencies

1. You need to have visual studio installed.
2. CatacombCrawler.java (the main class that runs the program)
3. Actor.java (supplemental class that stores the hero and monsters in the game as a custom "Actor" data type).
4. instructions.txt file - a simple text file containing game instructions displayed to the user in the game when "h" or "help" is requested

### How to run the project

Place all three required files in a single directory and then compile CatacombCrawler.java using the Visual Studio compiler.

### How to play the game


run program
Provide a name for your hero
provide the size of the catacomb between 5 and 10.
The game will create a grid with the x and y dimensions the same using the number you provided.  
The grid will look similar to the following example:

|----------------------------------------|
|  HERO  |       |       |       |       |
| HP:100 |       |       |       |       |
|----------------------------------------|
|        |       |       |Monster|       |
|        |       |       |HP: 25 |       |
|----------------------------------------|
| Monster|       |       |       |       |
| HP: 25 |       |       |       |       |
|----------------------------------------|
|        |       |Monster|       |       |
|        |       |HP: 25 |       |       |
|----------------------------------------|
|        |       |Monster|       |       |
|        |       |HP: 25 |       |       |
|----------------------------------------|

In the above example, the monsters will be hidden from view and only the Hero will be visible.

Objective of the game is to move from the upper left section of the catacomb to the bottom right.
Once you reach the bottom-right section without running out of health, you win.
Monsters exist in the catacomb which will cause you to fight and lose health.
Identification of nearby monsters is accomplished by smell.
--When monsters are nearby, I will tell you that you can smell them.

Commands you can provide the program include:

[N]orth
[S]outh
[E]east
[W]est
[G]rid - display catacomb grid showing hero location.
[Q]uit
-or-
[H]elp - display instructions.



## Lessons Learned

Working with ArrayList of a custom data class is difficult.  I spent hours trying to make changes to elements within the ArrayList by incorrectly treating them like a normal array.  I was almost going to try deleting killed monsters from the ArrayList by rebuilding it in a secondary temporary ArrayList.  It then occurred to me that the easiest way to accomplish my objective of being capable of removing killed monsters by simply adding a boolean isAlive variable true -or- false to the class definition.

Every single section/method/task took hours to accomplish and resulted in many lessons-learned & frustration.  Completion of the running program has resulted in a level of satisfaction that I didn't anticipate.

detangled bugs:
1. several instances of neglecting to use two equal signs in an if statement -- i.e. if (isAlive=true) instead of if (isAlive==true).
2. The ArrayList of monsters starts at 0 so displaying monsters.size to the users results in a numeric representation missing 1 monster.  I eventually recognized I needed to tell the player that the monster he/she is fighting is currentMonster+1 to have them start at "1" instead of "0"
3. Interrelated to the issue above (#2) was an if statement problem where I ran a method to identify which monster the hero landed on.  If the hero landed on monster number 0 in the ArrayList, the method returned 0.  I have an if statement that said "if (monsterNum > 0) then fight".  It took me a long time to recognize that logic was flawed because it wouldn't fight the single monster in ArrayList[0] because the if statement wasn't activated.  I resolved this by initializing "monsterNum" to -1 before running a CheckForMonstersToFight() method.  This way if it returned 0, that meant the Hero landed on monster number 0.  Then I changed my if statement to be "if (monsterNum > -1)" to test if the hero landed on a coordinate where a monster existed.  
