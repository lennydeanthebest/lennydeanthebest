import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.io.FileInputStream;

/**
 * Name: CatacombCrawler {class}
 * 
 * @author Tyler Dean
 * @dependancies Actor.class, instructions.txt
 * @features [g]rid command within program, diagnosticsflag set to true provides
 *           diagnostic detail for developers
 * 
 *           Primary class for the Catacomb Crawler game that includes main()
 *           and core functions.
 *           Depedancies exist for the program to properly compile and function.
 *           Actor.java is a separate dependant class which contains the class
 *           for an Actor data type.
 *           instructions.txt is a clear text file that is also required. It is
 *           displayed on the screen
 *           when the user asks for help.
 *           Includes a feature that shows the location of the hero on a grid if
 *           the user enters "g" or "grid" from the menu.
 *           Another hidden feature is within the code itself and requires
 *           recompiling to activate. This second feature is
 *           a boolean variable labeled "diagnosticsflag" within the definition
 *           section of main(). By default, this variable
 *           should be set to false for proper game operation. When set to true,
 *           it displays both the hero and all monsters
 *           when the user types in "g" or "grid" from the game menu. This was
 *           used to troubleshoot methods and game
 *           fuctionality during development. The feature was left disabled
 *           (false) but can be activated at any time.
 * 
 */
public class CatacombCrawler {

	/**
	 * Primary method that starts the game and serves as the main control center for
	 * user input and game actions.
	 * 
	 * @param args: // no command line arguments are used. This is ignored by the
	 *              application.
	 * @throws Exception // Most likely exception would include the application
	 *                   being unable to find
	 *                   the dependancy file "instructions.txt" from a method called
	 *                   by main().
	 * @return void
	 */
	public static void main(String[] args) throws Exception {
		displayHelpFile(); // updated to display useful help instructions before game starts
		System.out.println();
		System.out.print("Choose your name hero: ");
		Scanner readInput = new Scanner(System.in);
		String heroName = readInput.next(); // allows user to name the hero and then creates it
		Actor hero = new Actor(heroName, 100); // create new hero for user of type actor
		System.out.print("How wide of a catacomb do you want to face? (5-10) ");
		int dungeonSize = readInput.nextInt();
		int totalMonsters = 0;
		int whichMonsterNum = 0; // if I run into a monster, this stores which one in the array
		int winLose;
		boolean diagnosticsflag = false;
		boolean gameEnd = false;
		while ((dungeonSize < 5) || (dungeonSize > 10)) { // catacomb only of size 5x5-10x10 is allowed.
			System.out.println("That is not a vaild catacomb size.");
			System.out.print("How wide of a catacomb do you want to face? (5-10) ");
			dungeonSize = readInput.nextInt();
		}
		// at this point catacomb size must be between 5 and 10.
		// create array list to store monsters
		ArrayList<Actor> monsters = new ArrayList<Actor>(); // collection of all monsters contained inside catacomb

		// populate monsters in array list
		// -- use random locations
		totalMonsters = populateMonstersArray(dungeonSize, monsters);

		// catacomb population/creation
		char[][] Catacomb = new char[dungeonSize][dungeonSize];
		Catacomb[0][0] = 'H';
		for (int i = 0; i < monsters.size(); i++) {
			Actor currentMonster = monsters.get(i);
			int currentMonsterRow = currentMonster.getRow();
			int currentMonsterColumn = currentMonster.getColumn();
			Catacomb[currentMonsterRow][currentMonsterColumn] = (char) (i + 1);
			totalMonsters = i;
		}

		// start of game
		while (gameEnd == false) {
			System.out.printf("%s at %d, %d with %d health.\n", heroName, hero.getRow(), hero.getColumn(),
					hero.getHealth());
			// Check for nearby monsters using "smellMonsters" method
			System.out.printf("I smell %d monsters nearby.\n", smellForMonsters(Catacomb, hero, monsters, dungeonSize));
			System.out.print("What way would you like to go? (north, south, east, west)? ");
			Scanner userInput = new Scanner(System.in);
			String chosenDirection = userInput.next();
			switch (chosenDirection) {

				case "quit":
					gameEnd = true;
					break;
				case "q":
					gameEnd = true;
					break;
				case "help":
					displayHelpFile();
					break;
				case "h":
					displayHelpFile();
					break;
				case "north":
					move(Catacomb, hero, monsters, dungeonSize, "north");
					break;
				case "south":
					move(Catacomb, hero, monsters, dungeonSize, "south");
					break;
				case "east":
					move(Catacomb, hero, monsters, dungeonSize, "east");
					break;
				case "west":
					move(Catacomb, hero, monsters, dungeonSize, "west");
					break;
				case "n":
					move(Catacomb, hero, monsters, dungeonSize, "north");
					break;
				case "s":
					move(Catacomb, hero, monsters, dungeonSize, "south");
					break;
				case "e":
					move(Catacomb, hero, monsters, dungeonSize, "east");
					break;
				case "w":
					move(Catacomb, hero, monsters, dungeonSize, "west");
					break;
				case "grid":
					printCatacomb(Catacomb, monsters, hero, diagnosticsflag);
					break;
				case "g":
					printCatacomb(Catacomb, monsters, hero, diagnosticsflag);
					break;

				default:

					System.out.println("***********************************************");
					System.out.println("* Invalid game command or option.             *");
					System.out.println("* Type in \"help\" for game instructions.       *");
					System.out.println("***********************************************");
					break;
			}

			/*
			 * end of switch/case statement
			 * now we check to see if hero is out of health points and can't move. If true,
			 * game already lost.
			 */
			if (hero.getHealth() < 2) {
				gameEnd = true;
				System.out.println("You don't have enough health points to move.  Game over.");
			}

			// did hero reach bottom right corner?  If yes, the hero won the game
			if ((hero.getRow() == dungeonSize - 1) && (hero.getColumn() == dungeonSize - 1)) {
				gameEnd = true;
				System.out.println("You reached the destination.  You won.");
				System.exit(0);
			}

			
			// need to check if hero ran into monsters. If yes, then initiate a fight by
			// calling the method fight() later
			//
			whichMonsterNum = checkForMonstersToFight(Catacomb, hero, monsters, dungeonSize);
			if (whichMonsterNum != -1) {
				System.out.println("detected a monster");
				winLose = fight(hero, monsters, whichMonsterNum);
				System.out.println("your health is now " + winLose + " after the fight.");
			}
		}
		System.out.println("Thanks for playing. Exiting program.");
		System.exit(0);

		readInput.close();
	}

	/**
	 * This method reads a text file called instructions.txt and displays it on the screen.
	 * The purpose of this method is to serve as a help function for the game player (user).
	 * If the player types in "h" or "help", this method is activated to display the
	 * instructions.txt file.  The instructions.txt contains user instructions.
	 * @throws Exception Any exception.  Most anticipated exception would be file not found if instructions.txt file missing.
	 */
	public static void displayHelpFile() throws Exception {
		ArrayList<String> fileContents = new ArrayList<>();
		Scanner inputScanner = new Scanner(System.in); // scanner for main
		FileInputStream fileReader = new FileInputStream("instructions.txt"); // pull instructions
		Scanner fileScanner = new Scanner(fileReader);
		while (fileScanner.hasNextLine()) {
			System.out.println(fileScanner.nextLine());
			// fileContents.add(fileScanner.nextLine()); // read lines
		}
		fileScanner.close();
		fileReader.close();

	}
	/**
	 * displays catacomb grid to screen
	 * @param createdCatacomb	takes in a preexisting 2-D char array named createdCatacomb
	 * @param monsters			takes in an ArrayList of Actor type named monsters to store all monsters in the game
	 * @param hero				takes in a single Actor type data set that serves as the hero of the game
	 * @param diagnosticsflag	takes in a boolean true or false setting of diagnosticflag to potentially enable a
	 * 							developer feature that displays physical location of all monsters and the hero
	 * 							when the "g" or "grid" user option is selected from main() and passed to this method.
	 */
	public static void printCatacomb(char[][] createdCatacomb, ArrayList<Actor> monsters, Actor hero, boolean diagnosticsflag) { 
		System.out.print("|");
		for (int t = 0; t < createdCatacomb.length; t++) {
			System.out.printf("--------");
		}
		System.out.println("|");
		for (int i = 0; i < createdCatacomb.length; i++) {
			System.out.printf("| ");
			for (int j = 0; j < createdCatacomb.length; j++) {
				if (createdCatacomb[i][j] == 'H') {
					System.out.printf(" HERO  |");
				}

				if (diagnosticsflag == true) {
					if ((createdCatacomb[i][j] != 'H')
							&& (createdCatacomb[i][j] != '\0')) {
						System.out.printf("Monster|");
					}
					if (createdCatacomb[i][j] == '\0') {
						System.out.printf("       |");
					}
				} else if (createdCatacomb[i][j] != 'H') {
					System.out.printf("       |");
				}
			}
			System.out.print("\n");

			if (diagnosticsflag == true) {
				System.out.printf("| ");
				for (int j = 0; j < createdCatacomb.length; j++) {
					if (createdCatacomb[i][j] == 'H') {
						System.out.printf("HP:%3d |", hero.getHealth());
					}
					if (diagnosticsflag == true) {
						if ((createdCatacomb[i][j] != 'H')
								&& (createdCatacomb[i][j] != '\0')) {
							int curmonster = (int) createdCatacomb[i][j];
							curmonster--;
							Actor currentMonster = monsters.get(curmonster);
							System.out.printf("HP:%3d |",
									currentMonster.getHealth());
						}
						if (createdCatacomb[i][j] == '\0') {
							System.out.printf("       |");
						}
					} else
						System.out.printf("       |");
				}

				System.out.print("\n");
			}

			System.out.print("|");

			for (int t = 0; t < createdCatacomb.length; t++) {
				System.out.printf("--------");
			}
			System.out.println("|");
		}
	}

	/**
	 * This method uses a cardnial directional system
	 * The player of the game (user) can select "north", "south", "east", or "west"
	 * This method modifies the location of the player on the char 2-D array "Catacomb" and "hero" Actor type
	 * @param Catacomb					The 2-D character array containing an "H" to represent current location of hero
	 * @param hero						Actor type data set containing the hero name, health, row and column
	 * @param monsters					ArrayList of Actor type containing name, health, row and column of all monsters
	 * @param dungeonSize				A single integer representing the size of the catacomb as specified by player (user)
	 * @param chosenDirection			string containing "north", "south", "east" or "west" to indicate user requested direction
	 */
	public static void move(char[][] Catacomb, Actor hero, ArrayList<Actor> monsters, int dungeonSize, String chosenDirection) { 
		int currentHeroRow = hero.getRow();
		int currentHeroColumn = hero.getColumn();

		if (chosenDirection.equalsIgnoreCase("north")) {

			if (currentHeroRow < 1) {
				System.out.println("You are already on the top row.  You cannot move further North.");
			} else {
				System.out.println("We moved North");
				Catacomb[currentHeroRow][currentHeroColumn] = '\0';
				currentHeroRow--;
				Catacomb[currentHeroRow][currentHeroColumn] = 'H';
				hero.setRow(currentHeroRow);
				hero.setHealth(hero.getHealth() - 2); // remove 2 points from hero for moving
			}
		}

		if (chosenDirection.equalsIgnoreCase("south")) {

			if (currentHeroRow > (dungeonSize - 2)) {
				System.out.println("You are already on the bottom row.  You cannot move further South.");
			} else {
				System.out.println("We moved South");
				Catacomb[currentHeroRow][currentHeroColumn] = '\0';
				currentHeroRow++;
				Catacomb[currentHeroRow][currentHeroColumn] = 'H';
				hero.setRow(currentHeroRow);
				hero.setHealth(hero.getHealth() - 2); // remove 2 points from hero for moving
			}
		}

		if (chosenDirection.equalsIgnoreCase("east")) {

			if (currentHeroColumn > (dungeonSize - 2)) {
				System.out.println("You are as far East as you can move.");
			} else {
				System.out.println("We moved East");
				Catacomb[currentHeroRow][currentHeroColumn] = '\0';
				currentHeroColumn++;
				Catacomb[currentHeroRow][currentHeroColumn] = 'H';
				hero.setColumn(currentHeroColumn);
				hero.setHealth(hero.getHealth() - 2); // remove 2 points from hero for moving
			}
		}

		if (chosenDirection.equalsIgnoreCase("west")) {

			if (currentHeroColumn < 1) {
				System.out.println("You are as far West as you can move.");
			} else {
				System.out.println("We moved West");
				Catacomb[currentHeroRow][currentHeroColumn] = '\0';
				currentHeroColumn--;
				Catacomb[currentHeroRow][currentHeroColumn] = 'H';
				hero.setColumn(currentHeroColumn);
				hero.setHealth(hero.getHealth() - 2); // remove 2 points from hero for moving
			}
		}

	}

	/**
	 * This method calculates how many monsters are needed and creates the monsters by populating the ArrayList monsters
	 *   Random locations are established for each monster and protections within the code prevent duplicate monsters
	 *   within the same location (not adjacent) [too close] or being in the exact same spot (0,0) as the hero
	 * 
	 * @param dungeonSize	integer depicting the size of the catacomb. Used to calculate # of monsters required
	 * @param monsters		ArrayList to store the monsters (name, health, row, column)
	 * @return i				a single integer which depicts the # of monsters created
	 */
	public static int populateMonstersArray(int dungeonSize, ArrayList<Actor> monsters) {
		int i;
		for (i = 0; i < ((dungeonSize) * (dungeonSize)) / 6; i++) { // create monsters in random places inside the
																	// catacomb
			Actor currentMonster = new Actor("monster" + i, 25);
			Random randGen = new Random();
			int currentRowNum = 0;
			int currentColumnNum = 0;
			boolean monsterLocationIsBad = true;
			while (monsterLocationIsBad == true) {
				monsterLocationIsBad = false;

				currentRowNum = randGen.nextInt(dungeonSize); // get any random num <= dungeonsize
				currentColumnNum = randGen.nextInt(dungeonSize); // get any random num <= dungeonsize

				if ((currentRowNum == 0) && (currentColumnNum < 2)) {
					monsterLocationIsBad = true;
				}
				if ((currentColumnNum == 0) && (currentRowNum < 2)) {
					monsterLocationIsBad = true;
				}

				// Now we have some random location. Must verify its not a repeat
				// ----------------------------------------------------------------------------
				if (i > 0) {
					int existingMonsterRow;
					int existingMonsterColumn;
					for (int j = 0; j < monsters.size(); j++) {
						Actor existingMonster = monsters.get(j);
						existingMonsterRow = existingMonster.getRow();
						existingMonsterColumn = existingMonster.getColumn();
						if ((existingMonsterRow == currentRowNum)
								&& (existingMonsterColumn == currentColumnNum)) {
							monsterLocationIsBad = true;
						}

					}
				}
			}
			// ----------------------------------------------------------------------------

			// proceed to store monster array with selected location

			currentMonster.setRow(currentRowNum);
			currentMonster.setColumn(currentColumnNum);
			currentMonster.setAlive();
			monsters.add(currentMonster);
		}
		return i;
	}
	/**
	 * Method to determine if hero has moved into a physical location on the catacomb where a monster currently exists that is still alive
	 * if the hero lands on a spot where a monster exists, this method returns the number of the specific monster within the ArrayList Actor type named 
	 * monsters.
	 * @param Catacomb				The 2-D character array containing an "H" to represent current location of hero
	 * @param hero					Actor type data set containing the hero name, health, row and column
	 * @param monsters				ArrayList of Actor type containing name, health, row and column of all monsters
	 * @param dungeonSize			A single integer representing the size of the catacomb as specified by player (user)
	 * @return whichMonsterNum		The identifing number of the monster the hero landed on
	 */
	public static int checkForMonstersToFight(char[][] Catacomb, Actor hero, ArrayList<Actor> monsters,
			int dungeonSize) {
		int currentHeroRow = hero.getRow();
		int currentHeroColumn = hero.getColumn();
		int monsterRow, monsterColumn, whichMonsterNum = -1;
		boolean fightIsOn = false, monsterAlive;

		for (int i = 0; i < monsters.size(); i++) {
			Actor currentMonster = monsters.get(i);
			monsterRow = currentMonster.getRow();
			monsterColumn = currentMonster.getColumn();
			monsterAlive = currentMonster.isAlive();
			if (monsterAlive == true) {
				if ((currentHeroRow == monsterRow)
						&& (currentHeroColumn == monsterColumn)) {
					fightIsOn = true;
					whichMonsterNum = i;
				}
			}
			if (fightIsOn == true) {
				System.out.println("You ran into a monster.  Time to fight");

			}
		}
		return whichMonsterNum;
	}

	/**
	 * This method checks to see if monsters are nearby.
	 * @param Catacomb		The 2-D character array containing an "H" to represent current location of hero		
	 * @param hero			Actor type data set containing the hero name, health, row and column
	 * @param monsters		ArrayList of Actor type containing name, health, row and column of all monsters
	 * @param dungeonSize	A single integer representing the size of the catacomb as specified by player (user)
	 * @return smell		The number of monsters detected or "smelled" adjacent to the hero's location
	 */
	public static int smellForMonsters(char[][] Catacomb, Actor hero,
			ArrayList<Actor> monsters,
			int dungeonSize) {
		int currentHeroRow = hero.getRow();
		int currentHeroColumn = hero.getColumn();
		int monsterRow, monsterColumn, totalMonsters = 0;
		int smell = 0;
		boolean monsterAlive;

		for (int i = 0; i < monsters.size(); i++) {
			Actor currentMonster = monsters.get(i);
			monsterRow = currentMonster.getRow();
			monsterColumn = currentMonster.getColumn();
			monsterAlive = currentMonster.isAlive();
			if ((currentHeroRow == monsterRow + 1)
					&& (currentHeroColumn == monsterColumn) && (monsterAlive == true)) {
				smell++;
			}
			if ((currentHeroRow == monsterRow - 1)
					&& (currentHeroColumn == monsterColumn) && (monsterAlive == true)) {
				smell++;
			}
			if ((currentHeroRow == monsterRow)
					&& (currentHeroColumn == monsterColumn + 1)
					&& (monsterAlive == true)) {
				smell++;
			}
			if ((currentHeroRow == monsterRow)
					&& (currentHeroColumn == monsterColumn - 1)
					&& (monsterAlive == true)) {
				smell++;
			}
		}

		return smell;
	}

	
	/**
	 * This method initiates a fight between the hero and a monster
	 * @param hero					Actor type data set containing the hero name, health, row and column
	 * @param monsters				ArrayList of Actor type containing name, health, row and column of all monsters
	 * @param whichMonsterNum		The identifing number of the monster the hero landed on
	 * @return heroHealth			A single integer representing the health of the hero after the fight
	 */
	public static int fight(Actor hero, ArrayList<Actor> monsters,
			int whichMonsterNum) {

		int heroHealth, monsterRow, monsterColumn, monsterHealth, heroBattleHits, monsterBattleHits;
		Random randGen = new Random();
		Actor currentMonster = monsters.get(whichMonsterNum);
		monsterRow = currentMonster.getRow();
		monsterColumn = currentMonster.getColumn();
		monsterHealth = currentMonster.getHealth();
		heroHealth = hero.getHealth();

		System.out.println("Fighting monster number " + (whichMonsterNum + 1));

		while ((heroHealth > 0) && (monsterHealth > 0)) {
			while (monsterHealth > 0) {
				heroBattleHits = randGen.nextInt(10) + 1;
				System.out.println("You hit the monster with " + heroBattleHits + " of damage.");
				monsterBattleHits = randGen.nextInt(5) + 1;
				System.out.println("Monster hit you with " + monsterBattleHits + " of damage.");
				monsterHealth = monsterHealth - heroBattleHits;
				heroHealth = heroHealth - monsterBattleHits;
			}
			System.out.println("Monster " + (whichMonsterNum + 1) + " has been defeated.");
			// mark this monster as dead
			currentMonster.kill();
			monsters.get(whichMonsterNum);
			monsters.set(whichMonsterNum, currentMonster);
		}
		hero.setHealth(heroHealth);
		return heroHealth;
	}
	

}
