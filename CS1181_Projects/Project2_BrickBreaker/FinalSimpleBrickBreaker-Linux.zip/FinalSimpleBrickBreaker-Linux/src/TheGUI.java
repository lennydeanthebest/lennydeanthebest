
// Tyler Dean                               Brick Breaker Game (for Project 2)                          15 October 2024

///* I recieved help from the help room by Kalen on 10/16, Blake on 10/18, and Reece on 10/23 and 10/24 with this project */

// Imports
import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

/***
 * This class is where all of the GUI components for my Brick Breaker game are
 * created
 */
public class TheGUI {

    // fields
    private Random rand = new Random();
    private int score = 0;

    /**
     * This is the constructor that defines my "THEGUI" object which is created in
     * BrickBreaker.java. It contains all of the GUI components in this project
     * 
     * @SuppressWarnings ("static-access") // to remove the static-access warning on
     *                   EXIT_ON_CLOSE default close operation in THEGUI constructor
     * @param title // the title retreived from object creation
     */
    @SuppressWarnings("static-access") // to remove the static-access warning on EXIT_ON_CLOSE default close operation
                                       // in THEGUI constructor
    public TheGUI(String title) {
        JFrame gameWindow = new JFrame(); // create the gameWindow for the whole game

        // This newly created JOptionPanel consists of 4 arguments, the JFrame the panel
        // is inserted into, the text to
        // display on the screen, the title of the panel, and the type of symbol to
        // display (given numerically)
        JOptionPane.showMessageDialog(gameWindow, "How to play Brick Breaker: \n"
                + "You have control over a platform shifting from left to right (by arrow keys <-  ->) \n"
                + "The goal is to bounce the ball off of your platform to hit as many bricks as you can! (1 point per brick smashed) \n"
                + "Score is kept in the title bar of your window. \n"
                + "If the ball falls off the bottom of the screen, you lose the game! \n",
                "Brick Breaker Game Instructions:", 1);

        JPanel rootPanel = new JPanel(); // create the panel to hold all other panels
        rootPanel.setBackground(Color.GRAY); // color currently set to gray, can be changed to any color other than
                                             // colors used for the paddle, ball, and bricks
        rootPanel.setLayout(new BorderLayout());

        gameWindow.setSize(500, 500); // set the window's default size
        gameWindow.setTitle(title); // give the window the title specified in BrickBreaker.java
        gameWindow.setDefaultCloseOperation(gameWindow.EXIT_ON_CLOSE); // gameWindow should close when the X button is
                                                                       // clicked
        gameWindow.setContentPane(rootPanel); // set gameWindow's main panel to be root panel

        gameWindow.setVisible(true); // set the window to be visible

        BouncePanel gameSpace = new BouncePanel(rootPanel.getSize()); // create a new BouncePanel object with the size
                                                                      // being root panel's size
        Paddle paddle = new Paddle(rootPanel.getWidth() / 2 - 50, rootPanel.getHeight() - 40, rootPanel.getSize()); // create
                                                                                                                    // new
                                                                                                                    // Paddle
                                                                                                                    // object
                                                                                                                    // with
                                                                                                                    // a
                                                                                                                    // width,
                                                                                                                    // height,
                                                                                                                    // and
                                                                                                                    // size

        rootPanel.revalidate(); // Revalidate the panel to layout the new components
        rootPanel.repaint(); // Redraw the panel

        ArrayList<Brick> theBricks = new ArrayList<>(); // Create a list to store Bricks
        int randBrickNum = rand.nextInt(10) + 1; // Create a random number between 1 and 11

        for (int i = 0; i < randBrickNum; i++) { // Create randBrickNum number of bricks
            Brick brick = getRandBrickLocation();
        
            // Loop until we find a non-overlapping position for the brick
            boolean overlaps = false;;
            do {
                overlaps = false; // set to false at beginning so doLoop exits if proposed rand() values are good
                for (int j = 0; j < theBricks.size(); j++) {
                    Brick oldBrick = theBricks.get(j);
                    int oldX = oldBrick.getBrickX();
                    int oldY = oldBrick.getBrickY();
                    int proposedX = brick.getBrickX();
                    int proposedY = brick.getBrickY();
        
                    // Check if the proposed brick overlaps with an existing one
                    if (Math.abs(proposedX - oldX) < 50 && Math.abs(proposedY - oldY) < 25) {
                        overlaps = true;
                        break;
                    }
                }
        
                // Get a new position if it overlaps
                if (overlaps == true) {
                    brick = getRandBrickLocation();
                }
            } while (overlaps == true);
        
            // Add the brick to the list after confirming it doesn't overlap
            theBricks.add(brick);
        }
        
        
        gameSpace.setLayout(null); // override gameSpace's current layout to setup bricks properly

        for (Brick b : theBricks) { // nice foreach loop to add every brick in theBricks array list to gameSpace
                                    // BouncePanel
            gameSpace.add(b);

        }

        rootPanel.add(gameSpace, BorderLayout.CENTER); // add the gameSpace panel to the root panel

        rootPanel.add(paddle, BorderLayout.CENTER); // add the paddle to the root panel

        gameWindow.addKeyListener(new KeyListener() { // to detect user keyboard input (specifically <- and -> keys)

            /**
             * This method inside of my "THEGUI" constructor I am not using and only include
             * it because the KeyListener interface requires it
             * 
             * @param e // the KeyEvent passed into method which is the button they typed
             * @Override // annotation to express intentional overriding
             */
            @Override
            public void keyTyped(KeyEvent e) {
                // does nothing, needed for KeyListener
            }

            /**
             * This method inside of my "THEGUI" constructor handles the event that a key is
             * pressed (held down) by the user
             * 
             * @param e // the KeyEvent passed into method which is the button they pressed
             * @Override // annotation to express intentional overriding
             */
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode(); // retrieve the KeyCode of e and store it into an int
                if (key == 37) { // Code for left arrow (<-) key. Means player pressed, and is holding the left
                                 // arrow (<-) key.
                    paddle.moveLeft(); // call this method from Paddle.java
                } else if (key == 39) { // Code for right arrow (->) key. Means player pressed, and is holding the right
                                        // arrow (->) key.
                      paddle.moveRight(); // call this method from Paddle.java
                }
            }

            /**
             * This method inside of my "THEGUI" constructor handles the event that a key is
             * released (let go) by the user
             * 
             * @param e // the KeyEvent passed into method which is the button they pressed
             * @Override // annotation to express intentional overriding
             */
            @Override
            public void keyReleased(KeyEvent e) {
                paddle.paddleStop(); // call this method from Paddle.java
            }

        });

        Timer timer = new Timer(5, e -> { // lambda function for controling movement of GUI elements
            gameSpace.animate(); // calling animate method on gameSpace which is a BouncePanel
            paddle.animate(); // calling animate method on paddle which is a JComponent

            // Check to see if ball hit the paddle, if so reverse it's direction (must do
            // here because paddle and ball methods need to be in scope)
            if (gameSpace.getCircleX() >= paddle.getPaddleX() && gameSpace.getCircleX() <= paddle.getPaddleX() + 100
                    && gameSpace.getCircleY() >= paddle.getHeight() - 50 // complex if condition checking whether or not
                                                                         // the ball hit the paddle
                    && gameSpace.getCircleY() <= paddle.getHeight() - 50 + 20) {
                int circleYValue = gameSpace.getCircleY(); // store the circle's current y value in a variable
                circleYValue = paddle.getHeight() - 50; // the variable now = the current height of the paddle - 50
                gameSpace.setCircleY(circleYValue); // set the circle's y value to this
                int circleDeltaYValue = gameSpace.getDeltaY(); // store the circle's current deltaY value in a variable
                circleDeltaYValue = gameSpace.getDeltaY() * -1; // the variable now = the gameSpace bounce panel's
                                                                // deltaY value * -1 (to reverse direction)
                gameSpace.setCircleDeltaY(circleDeltaYValue); // set the circle's deltaY value to this
                               
            }
            // loop through all bricks in theBricks array list, and check if the ball hit a
            // brick
            for (int i = 0; i < theBricks.size(); i++) {
                // If so, remove the brick that was hit
                if ((gameSpace.getCircleY() < theBricks.get(i).getY() + 25 // complex if condition to check whether or
                                                                           // not the ball hit a brick
                        && gameSpace.getCircleY() > theBricks.get(i).getY())
                        && (theBricks.get(i).getX() < gameSpace.getCircleX()
                                && gameSpace.getCircleX() < theBricks.get(i).getX() + 50)) { // inside if statement do
                                                                                             // the following
                    gameSpace.setCircleDeltaY(-gameSpace.getDeltaY()); // reverse direction of the ball
                    gameSpace.remove(theBricks.get(i)); // remove brick from the screen
                    gameSpace.revalidate(); // revalidate the panel to validate the new components
                    gameSpace.repaint(); // redraw the screen
                    score++; // increment the score by 1 each time ball hit a brick
                    gameWindow.setTitle("Score: " + score); // change title of gameWindw to display the user's score
                    theBricks.remove(i); // remove brick from the list of bricks
                }

                if (theBricks.size() == 0) { // there are no more bricks

                    JOptionPane.showMessageDialog(gameWindow, "You have won the game with " + score + " points!",
                            "Congratulations, you have won the game!!!!!", 2); // create and fill new OptionPane with
                                                                               // these contents
                    System.exit(0); // exit the game

                }

            }
            // **************************************************************************
            // **** rootPanel-repaint worked in Linux, doesn't work in MS Windows
            rootPanel.repaint(); // call the rootPanel's paintComponent method
            // **************************************************************************
            // added to force repainting in MS Windows.  Worked in Linux without it.
            gameWindow.repaint();
            // **************************************************************************
            // Improvement idea
            // With use of gameWindow.repaint, the darker background is replaced with
            //   a lighter background that is undesireable.  This could use repair
            //   If gameWindow.repaint is removed, the darker background remains, but
            //   the ball and paddle will not redraw correctly.  Both gameSpace.repaint
            //   and rootPanel.repaint leave the desired dark background, but fail to
            //   repaint the screen correctly.
            // **************************************************************************

        });
        timer.start(); // start the timer above after it's contents are initalized

    }

    public Brick getRandBrickLocation() {
        int randXNum;
        int randYNum;
        randXNum = rand.nextInt(400) + 50; // random x location between width of gameWindow - 50
        randYNum = rand.nextInt(225) + 25; // random y location between height of gameWindow
        Brick brick = new Brick(randXNum, randYNum, new Dimension(50, 25)); // Adjust brick position and size
        return brick;
    }
}
